This module allows you to use hierarchical_select (version 7.x-3.x) as a widget
for a taxonomy-based entityreference field.

To use it, create an entityreference field, with the Hierarchical Select widget,
select "Taxonomy term" as the target type, and select one vocabulary (you must
choose exactly one) as the target bundle.

Credit: John Morahan, iO1 and iVillage.
